const fs = require('fs');
const Tag = require('../models/TagSchema');

module.exports = (req, res) => {
  if (req.pathname === '/search') {
   
  } else {
    return true
  }
}
